---
title: Anonimizador V2
emoji: 👀
colorFrom: gray
colorTo: green
sdk: gradio
sdk_version: 4.42.0
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
